# English Tutor GPT

## Overview

English Tutor GPT is a web-based AI-powered English tutoring application that provides personalized language learning assistance through conversational interactions. The application leverages OpenAI's GPT models to offer real-time English tutoring, grammar correction, vocabulary assistance, and conversational practice. Users can create accounts, engage in multiple chat sessions, and access their conversation history through an intuitive web interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application uses a traditional server-rendered HTML architecture with vanilla JavaScript for interactivity. The frontend is organized into modular JavaScript classes:

- **Auth class**: Handles user authentication, login/logout, and token management
- **Chat class**: Manages chat functionality, message sending, and conversation history
- **Payment class**: Integrates with Stripe for payment processing
- **UI class**: Controls theming, sidebar navigation, and modal interactions
- **Walkthrough class**: Provides guided tour functionality for new users

The frontend supports multiple themes (default, light, dark) with CSS custom properties for consistent styling across the application.

### Backend Architecture
The backend is built with Express.js following a modular route-based architecture:

- **Authentication routes** (`/api/auth`): Handle user registration, login, and JWT token management
- **Chat routes** (`/api/chat`): Manage chat creation, retrieval, and OpenAI API integration
- **Payment routes** (`/api/payment`): Process Stripe payments and update user payment status

The application uses JWT tokens for authentication with both access and refresh token implementation. Middleware functions handle authentication across protected routes.

### Data Storage
The application uses PostgreSQL as the primary database with a connection pooling strategy. The database layer is organized with:

- **Connection module**: Manages PostgreSQL connection pool with SSL support for production
- **Initialization module**: Sets up database schema on application startup
- **Queries module**: Provides data access methods for users, chats, and related operations

Database operations include user management, chat history storage, and payment status tracking.

### AI Integration
OpenAI GPT integration is implemented through the official OpenAI Node.js SDK. The application sends user messages to GPT models and streams responses back to the frontend, enabling real-time conversational tutoring experiences.

### Authentication & Authorization
The system implements JWT-based authentication with:

- **Access tokens**: Short-lived tokens for API requests
- **Refresh tokens**: Long-lived tokens stored securely for token renewal
- **Password hashing**: Uses bcryptjs for secure password storage
- **Route protection**: Middleware-based authentication for protected endpoints

### Payment Integration
Stripe payment processing is integrated to monetize the tutoring service:

- **Payment intents**: Server-side payment intent creation
- **Client-side checkout**: Stripe Elements for secure card processing
- **Payment verification**: Server-side payment confirmation and user status updates

## External Dependencies

### Core Dependencies
- **Express.js**: Web application framework for Node.js
- **PostgreSQL**: Primary database using the `pg` driver
- **OpenAI API**: AI language model integration for tutoring functionality
- **Stripe**: Payment processing platform for subscription management

### Authentication & Security
- **bcryptjs**: Password hashing and verification
- **jsonwebtoken**: JWT token generation and verification
- **dotenv**: Environment variable management

### Frontend Assets
- **Font Awesome**: Icon library for UI components
- **Stripe.js**: Client-side payment processing library

### Environment Configuration
The application requires several environment variables:
- `DATABASE_URL`: PostgreSQL connection string
- `OPENAI_API_KEY`: OpenAI API authentication key
- `STRIPE_SECRET_KEY`: Stripe server-side API key
- `ACCESS_TOKEN_SECRET`: JWT signing secret
- `REQUIRE_PAYMENT`: Boolean flag for payment requirement
- `NODE_ENV`: Environment specification for SSL configuration