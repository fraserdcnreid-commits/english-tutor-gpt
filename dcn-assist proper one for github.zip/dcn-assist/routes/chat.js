const express = require('express');
const router = express.Router();
const { OpenAI } = require('openai');
const jwt = require('jsonwebtoken');
const { getChatsByUserId, getChatById, createChat, updateChat, deleteChat, searchChatsByTitle } = require('../db/queries');

// Authentication middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Get all chats for a user
router.get('/', authenticateToken, async (req, res) => {
  try {
    const chats = await getChatsByUserId(req.user.id);
    res.json(chats);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Search chats by title
router.get('/search', authenticateToken, async (req, res) => {
  try {
    const { query } = req.query;

    if (!query) {
      return res.status(400).json({ message: 'Search query is required' });
    }

    const matchingChats = await searchChatsByTitle(req.user.id, query);
    res.json(matchingChats);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get a specific chat
router.get('/:chatId', authenticateToken, async (req, res) => {
  try {
    const { chatId } = req.params;
    const chat = await getChatById(req.user.id, chatId);

    if (!chat) {
      return res.status(404).json({ message: 'Chat not found' });
    }

    res.json(chat);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create a new chat
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { title } = req.body;

    const chatId = Date.now().toString();
    const chat = {
      id: chatId,
      userId: req.user.id,
      title: title || 'New Chat',
      messages: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const savedChat = await createChat(chat);
    res.status(201).json(savedChat);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update a chat
router.put('/:chatId', authenticateToken, async (req, res) => {
  try {
    const { chatId } = req.params;
    const { title, messages } = req.body;

    const updates = {};
    if (title) updates.title = title;
    if (messages) updates.messages = messages;
    
    const updatedChat = await updateChat(req.user.id, chatId, updates);
    if (!updatedChat) {
      return res.status(404).json({ message: 'Chat not found' });
    }
    
    res.json(updatedChat);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete a chat
router.delete('/:chatId', authenticateToken, async (req, res) => {
  try {
    const { chatId } = req.params;
    const deleted = await deleteChat(req.user.id, chatId);
    if (!deleted) {
      return res.status(404).json({ message: 'Chat not found' });
    }
    
    res.json({ message: 'Chat deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Send a message to GPT
router.post('/message', authenticateToken, async (req, res) => {
  try {
    const { chatId, message } = req.body;

    if (!chatId || !message) {
      return res.status(400).json({ message: 'Chat ID and message are required' });
    }

    const chat = await getChatById(req.user.id, chatId);

    if (!chat) {
      return res.status(404).json({ message: 'Chat not found' });
    }

    const userMessage = {
      role: 'user',
      content: message,
      timestamp: new Date().toISOString()
    };

    chat.messages.push(userMessage);

    const apiMessages = chat.messages.map(msg => ({
      role: msg.role,
      content: msg.content
    }));

    const completion = await openai.chat.completions.create({
      model: 'gpt-4', // or your custom GPT model
      messages: apiMessages,
      temperature: 0.7,
      max_tokens: 1000
    });

    const gptResponse = completion.choices[0].message.content;

    const assistantMessage = {
      role: 'assistant',
      content: gptResponse,
      timestamp: new Date().toISOString()
    };

    chat.messages.push(assistantMessage);
    const updatedChat = await updateChat(req.user.id, chatId, { messages: chat.messages });

    res.json({
      message: 'Message sent successfully',
      userMessage,
      assistantMessage,
      chat: updatedChat
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;