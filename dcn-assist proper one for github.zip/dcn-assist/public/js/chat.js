// Chat functionality
class Chat {
  constructor() {
    this.currentChatId = null;
    this.chats = [];
    this.init();
  }

  init() {
    // Check if user is authenticated
    if (!auth.isAuthenticated()) {
      window.location.href = '/login';
      return;
    }

    // Check if user has paid
    if (!auth.hasPaid()) {
      window.location.href = '/payment';
      return;
    }

    // Initialize chat elements
    this.chatList = document.getElementById('chat-list');
    this.chatMessages = document.getElementById('chat-messages');
    this.chatInput = document.getElementById('chat-input');
    this.sendMessageBtn = document.getElementById('send-message-btn');
    this.newChatBtn = document.getElementById('new-chat-btn');
    this.chatSearch = document.getElementById('chat-search');
    this.welcomeMessage = document.getElementById('welcome-message');
    this.chatInputContainer = document.getElementById('chat-input-container');

    // Add event listeners
    if (this.sendMessageBtn) {
      this.sendMessageBtn.addEventListener('click', this.sendMessage.bind(this));
    }

    if (this.chatInput) {
      this.chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          this.sendMessage();
        }
      });
    }

    if (this.newChatBtn) {
      this.newChatBtn.addEventListener('click', this.createNewChat.bind(this));
    }

    if (this.chatSearch) {
      this.chatSearch.addEventListener('input', this.searchChats.bind(this));
    }

    // Load chats
    this.loadChats();

    // Check if first login and show walkthrough
    if (auth.isFirstLogin()) {
      setTimeout(() => {
        walkthrough.start();
      }, 500);
    }
  }

  async loadChats() {
    try {
      const response = await fetch(`/api/chat?userId=${auth.user.id}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${auth.accessToken}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to load chats');
      }

      this.chats = await response.json();
      this.renderChatList();
    } catch (error) {
      console.error('Error loading chats:', error);

      // Try refreshing token and retry
      await auth.refreshAccessToken();
      this.loadChats();
    }
  }

  renderChatList() {
    if (!this.chatList) return;

    this.chatList.innerHTML = '';

    if (this.chats.length === 0) {
      this.chatList.innerHTML = '<p class="text-center text-muted">No chats yet</p>';
      return;
    }

    this.chats.forEach(chat => {
      const chatItem = document.createElement('div');
      chatItem.className = `chat-item ${chat.id === this.currentChatId ? 'active' : ''}`;
      chatItem.dataset.chatId = chat.id;

      chatItem.innerHTML = `
        <div class="chat-title">${chat.title}</div>
        <div class="chat-item-actions">
          <button class="rename-chat-btn" title="Rename">
            <i class="fas fa-edit"></i>
          </button>
          <button class="delete-chat-btn" title="Delete">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      `;

      // Add event listeners
      chatItem.addEventListener('click', (e) => {
        if (!e.target.closest('.chat-item-actions')) {
          this.loadChat(chat.id);
        }
      });

      const renameBtn = chatItem.querySelector('.rename-chat-btn');
      renameBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.showRenameChatModal(chat.id, chat.title);
      });

      const deleteBtn = chatItem.querySelector('.delete-chat-btn');
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.showDeleteChatModal(chat.id);
      });

      this.chatList.appendChild(chatItem);
    });
  }

  async loadChat(chatId) {
    try {
      const response = await fetch(`/api/chat/${chatId}?userId=${auth.user.id}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${auth.accessToken}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to load chat');
      }

      const chat = await response.json();
      this.currentChatId = chatId;

      // Update active chat in UI
      document.querySelectorAll('.chat-item').forEach(item => {
        item.classList.toggle('active', item.dataset.chatId === chatId);
      });

      // Show chat messages and input
      this.welcomeMessage.style.display = 'none';
      this.chatMessages.style.display = 'flex';
      this.chatInputContainer.style.display = 'flex';

      // Render messages
      this.renderMessages(chat.messages);
    } catch (error) {
      console.error('Error loading chat:', error);

      // Try refreshing token and retry
      await auth.refreshAccessToken();
      this.loadChat(chatId);
    }
  }

  renderMessages(messages) {
    if (!this.chatMessages) return;

    this.chatMessages.innerHTML = '';

    messages.forEach(message => {
      const messageElement = document.createElement('div');
      messageElement.className = `message ${message.role}`;
      messageElement.textContent = message.content;
      this.chatMessages.appendChild(messageElement);
    });

    // Scroll to bottom
    this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
  }

  async sendMessage() {
    const message = this.chatInput.value.trim();

    if (!message || !this.currentChatId) return;

    // Add user message to UI
    const userMessageElement = document.createElement('div');
    userMessageElement.className = 'message user';
    userMessageElement.textContent = message;
    this.chatMessages.appendChild(userMessageElement);

    // Clear input
    this.chatInput.value = '';

    // Scroll to bottom
    this.chatMessages.scrollTop = this.chatMessages.scrollHeight;

    // Disable input while waiting for response
    this.chatInput.disabled = true;
    this.sendMessageBtn.disabled = true;

    try {
      const response = await fetch('/api/chat/message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${auth.accessToken}`
        },
        body: JSON.stringify({
          userId: auth.user.id,
          chatId: this.currentChatId,
          message
        })
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      const data = await response.json();

      // Add assistant message to UI
      const assistantMessageElement = document.createElement('div');
      assistantMessageElement.className = 'message assistant';
      assistantMessageElement.textContent = data.assistantMessage.content;
      this.chatMessages.appendChild(assistantMessageElement);

      // Update chat title if it's the first message
      const chatIndex = this.chats.findIndex(chat => chat.id === this.currentChatId);
      if (chatIndex !== -1 && this.chats[chatIndex].messages.length === 0) {
        // Generate a title from the first message
        const title = message.length > 30 ? message.substring(0, 30) + '...' : message;
        this.chats[chatIndex].title = title;

        // Update chat in backend
        this.updateChatTitle(this.currentChatId, title);

        // Update chat list
        this.renderChatList();
      }

      // Update messages in chat object
      this.chats[chatIndex].messages = data.chat.messages;

      // Scroll to bottom
      this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    } catch (error) {
      console.error('Error sending message:', error);

      // Try refreshing token and retry
      await auth.refreshAccessToken();
      this.sendMessage();
    } finally {
      // Re-enable input
      this.chatInput.disabled = false;
      this.sendMessageBtn.disabled = false;
      this.chatInput.focus();
    }
  }

  async createNewChat() {
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${auth.accessToken}`
        },
        body: JSON.stringify({
          userId: auth.user.id,
          title: 'New Chat'
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create new chat');
      }

      const newChat = await response.json();

      // Add to chats array
      this.chats.unshift(newChat);

      // Update chat list
      this.renderChatList();

      // Load the new chat
      this.loadChat(newChat.id);
    } catch (error) {
      console.error('Error creating new chat:', error);

      // Try refreshing token and retry
      await auth.refreshAccessToken();
      this.createNewChat();
    }
  }

  async updateChatTitle(chatId, title) {
    try {
      const response = await fetch(`/api/chat/${chatId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${auth.accessToken}`
        },
        body: JSON.stringify({
          userId: auth.user.id,
          title
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update chat title');
      }
    } catch (error) {
      console.error('Error updating chat title:', error);

      // Try refreshing token and retry
      await auth.refreshAccessToken();
      this.updateChatTitle(chatId, title);
    }
  }

  async deleteChat(chatId) {
    try {
      const response = await fetch(`/api/chat/${chatId}?userId=${auth.user.id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${auth.accessToken}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to delete chat');
      }

      // Remove from chats array
      this.chats = this.chats.filter(chat => chat.id !== chatId);

      // Update chat list
      this.renderChatList();

      // If deleted chat was current chat, show welcome message
      if (chatId === this.currentChatId) {
        this.currentChatId = null;
        this.welcomeMessage.style.display = 'flex';
        this.chatMessages.style.display = 'none';
        this.chatInputContainer.style.display = 'none';
      }
    } catch (error) {
      console.error('Error deleting chat:', error);

      // Try refreshing token and retry
      await auth.refreshAccessToken();
      this.deleteChat(chatId);
    }
  }

  showRenameChatModal(chatId, currentTitle) {
    const modal = document.getElementById('rename-chat-modal');
    const input = document.getElementById('rename-chat-input');
    const cancelBtn = document.getElementById('cancel-rename-chat');
    const confirmBtn = document.getElementById('confirm-rename-chat');
    const closeBtn = document.getElementById('close-rename-chat');

    // Set current title
    input.value = currentTitle;

    // Show modal
    modal.classList.add('show');

    // Focus input
    setTimeout(() => {
      input.focus();
      input.select();
    }, 100);

    // Event listeners
    const closeModal = () => {
      modal.classList.remove('show');
    };

    const renameChat = async () => {
      const newTitle = input.value.trim();

      if (!newTitle) return;

      // Update chat title
      await this.updateChatTitle(chatId, newTitle);

      // Update chat in array
      const chatIndex = this.chats.findIndex(chat => chat.id === chatId);
      if (chatIndex !== -1) {
        this.chats[chatIndex].title = newTitle;
      }

      // Update chat list
      this.renderChatList();

      // Close modal
      closeModal();
    };

    cancelBtn.onclick = closeModal;
    closeBtn.onclick = closeModal;
    confirmBtn.onclick = renameChat;

    input.onkeydown = (e) => {
      if (e.key === 'Enter') {
        renameChat();
      } else if (e.key === 'Escape') {
        closeModal();
      }
    };
  }

  showDeleteChatModal(chatId) {
    const modal = document.getElementById('delete-chat-modal');
    const cancelBtn = document.getElementById('cancel-delete-chat');
    const confirmBtn = document.getElementById('confirm-delete-chat');
    const closeBtn = document.getElementById('close-delete-chat');

    // Show modal
    modal.classList.add('show');

    // Event listeners
    const closeModal = () => {
      modal.classList.remove('show');
    };

    const deleteChat = async () => {
      await this.deleteChat(chatId);
      closeModal();
    };

    cancelBtn.onclick = closeModal;
    closeBtn.onclick = closeModal;
    confirmBtn.onclick = deleteChat;
  }

  async searchChats() {
    const query = this.chatSearch.value.trim().toLowerCase();

    if (!query) {
      this.renderChatList();
      return;
    }

    try {
      const response = await fetch(`/api/chat/search?userId=${auth.user.id}&query=${encodeURIComponent(query)}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${auth.accessToken}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to search chats');
      }

      const matchingChats = await response.json();

      // Update chat list with search results
      this.chatList.innerHTML = '';

      if (matchingChats.length === 0) {
        this.chatList.innerHTML = '<p class="text-center text-muted">No matching chats</p>';
        return;
      }

      matchingChats.forEach(chat => {
        const chatItem = document.createElement('div');
        chatItem.className = `chat-item ${chat.id === this.currentChatId ? 'active' : ''}`;
        chatItem.dataset.chatId = chat.id;

        chatItem.innerHTML = `
          <div class="chat-title">${chat.title}</div>
          <div class="chat-item-actions">
            <button class="rename-chat-btn" title="Rename">
              <i class="fas fa-edit"></i>
            </button>
            <button class="delete-chat-btn" title="Delete">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        `;

        // Add event listeners
        chatItem.addEventListener('click', (e) => {
          if (!e.target.closest('.chat-item-actions')) {
            this.loadChat(chat.id);
          }
        });

        const renameBtn = chatItem.querySelector('.rename-chat-btn');
        renameBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.showRenameChatModal(chat.id, chat.title);
        });

        const deleteBtn = chatItem.querySelector('.delete-chat-btn');
        deleteBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          this.showDeleteChatModal(chat.id);
        });

        this.chatList.appendChild(chatItem);
      });
    } catch (error) {
      console.error('Error searching chats:', error);

      // Try refreshing token and retry
      await auth.refreshAccessToken();
      this.searchChats();
    }
  }
}

// Initialize chat
const chat = new Chat();