// Main application entry point
document.addEventListener('DOMContentLoaded', async () => {
  console.log('=== DEBUG: DOM Content Loaded ===');
  console.log('Current URL:', window.location.href);
  console.log('Current path:', window.location.pathname);

  // Check if auth object exists
  console.log('Auth object exists:', typeof auth !== 'undefined');
  if (typeof auth !== 'undefined') {
    console.log('Auth methods:', {
      isAuthenticated: typeof auth.isAuthenticated,
      hasPaid: typeof auth.hasPaid
    });
  } else {
    console.log('ERROR: Auth object not found!');
    return;
  }

  // Fetch configuration
  let requirePayment = false;
  try {
    console.log('Fetching configuration...');
    const response = await fetch('/api/config', {
      headers: {
        'Authorization': `Bearer ${auth.accessToken}`
      }
    });
    console.log('Config response status:', response.status);
    if (response.ok) {
      const config = await response.json();
      requirePayment = config.requirePayment;
      console.log('Configuration loaded:', config);
    } else {
      console.error('Config response not OK:', response.status);
    }
  } catch (error) {
    console.error('Error fetching config:', error);
  }

  // Check localStorage for tokens
  const accessToken = localStorage.getItem('accessToken');
  const refreshToken = localStorage.getItem('refreshToken');
  const userStr = localStorage.getItem('user');
  let user = null;

  try {
    user = userStr ? JSON.parse(userStr) : null;
  } catch (e) {
    console.error('Error parsing user from localStorage:', e);
  }

  console.log('=== DEBUG: Token Check ===');
  console.log('Access token in localStorage:', accessToken ? 'Present' : 'Missing');
  console.log('Refresh token in localStorage:', refreshToken ? 'Present' : 'Missing');
  console.log('User in localStorage:', user ? 'Present' : 'Missing');

  if (user) {
    console.log('User data:', user);
  }

  // Check if we're on an auth page
  const isAuthPage = window.location.pathname === '/login' || 
                   window.location.pathname === '/signup' ||
                   window.location.pathname === '/payment';

  console.log('=== DEBUG: Page Check ===');
  console.log('Is auth page:', isAuthPage);

  if (!isAuthPage) {
    console.log('=== DEBUG: Authentication Check ===');
    // Check if user is authenticated
    const isAuthenticated = auth.isAuthenticated();
    console.log('Is authenticated (from auth object):', isAuthenticated);

    if (!isAuthenticated) {
      console.log('Not authenticated, redirecting to login');
      // Only redirect if we're not already on login page
      if (window.location.pathname !== '/login') {
        console.log('Redirecting to login - not authenticated');
        window.location.href = '/login';
      }
      return;
    }

    // Check if user has paid
    const hasPaid = auth.hasPaid();
    console.log('Has paid (from auth object):', hasPaid);

    if (!hasPaid && 
        requirePayment && 
        window.location.pathname !== '/payment') {
      console.log('Redirecting to payment - payment required but not paid');
      window.location.href = '/payment';
      return;
    }

    console.log('=== DEBUG: All Checks Passed ===');
    console.log('Authentication and payment checks passed');
  }

  // Initialize components based on current page
  if (window.location.pathname === '/dashboard' || window.location.pathname === '/') {
    console.log('=== DEBUG: Initializing Components ===');
    // Chat and UI components are already initialized in their respective files
    console.log('Application initialized');
  }
});