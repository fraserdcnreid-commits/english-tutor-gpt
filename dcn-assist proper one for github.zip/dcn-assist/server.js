const express = require('express');
const app = express();
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const { OpenAI } = require('openai');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { initializeDatabase } = require('./db/init');
const { getUserById, updateUser } = require('./db/queries');

dotenv.config();

// Initialize database on startup
initializeDatabase().catch(console.error);

app.use(express.json());
app.use(express.static('public'));

// CSP headers removed to resolve loading issues
// app.use((req, res, next) => {
//   res.setHeader(
//     'Content-Security-Policy',
//     "default-src *; script-src * 'unsafe-inline'; style-src * 'unsafe-inline'; img-src * data:; font-src *; connect-src *"
//   );
//   next();
// });

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Import routes
const authRoutes = require('./routes/auth');
const chatRoutes = require('./routes/chat');
const paymentRoutes = require('./routes/payment');

app.use('/api/auth', authRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/payment', paymentRoutes);

// Serve HTML files
app.get('/', (req, res) => {
  // Redirect to login - authentication will be handled by JavaScript
  res.redirect('/login');
});

app.get('/login', (req, res) => {
  console.log('Login route accessed');
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.get('/signup', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'signup.html'));
});

app.get('/dashboard', async (req, res) => {
  try {
    // Serve the main app - authentication will be handled by JavaScript
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  } catch (error) {
    console.error(error);
    res.status(500).send('Server error');
  }
});

app.get('/payment', async (req, res) => {
  try {
    // Serve the payment page - authentication will be handled by JavaScript
    res.sendFile(path.join(__dirname, 'views', 'payment.html'));
  } catch (error) {
    console.error(error);
    res.status(500).send('Server error');
  }
});

// Authentication middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// getUserById is now imported from db/queries.js
// Configuration endpoint
app.get('/api/config', (req, res) => {
  res.json({
    requirePayment: process.env.REQUIRE_PAYMENT === 'true'
  });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});