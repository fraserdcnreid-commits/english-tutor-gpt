// Authentication functionality
class Auth {
  constructor() {
    this.accessToken = localStorage.getItem('accessToken');
    this.refreshToken = localStorage.getItem('refreshToken');
    this.user = JSON.parse(localStorage.getItem('user') || '{}');
    this.init();
  }

  init() {
    // Check if we're on the login or signup page
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');

    if (loginForm) {
      loginForm.addEventListener('submit', this.handleLogin.bind(this));
    }

    if (signupForm) {
      signupForm.addEventListener('submit', this.handleSignup.bind(this));
    }

    // Logout link
    const logoutLink = document.getElementById('logout-link');
    if (logoutLink) {
      logoutLink.addEventListener('click', this.handleLogout.bind(this));
    }

    // Check if token needs refreshing
    if (this.accessToken) {
      this.setupTokenRefresh();
    }
  }

  async handleLogin(e) {
    e.preventDefault();
    console.log('Login form submitted');

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorElement = document.getElementById('login-error');

    console.log('Email:', email);
    console.log('Password provided:', password ? 'Yes' : 'No');

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });

      console.log('Login response status:', response.status);
      const data = await response.json();
      console.log('Login response data:', data);

      if (!response.ok) {
        throw new Error(data.message || 'Login failed');
      }

      // Save tokens and user info
      this.accessToken = data.accessToken;
      this.refreshToken = data.refreshToken;
      this.user = data.user;

      console.log('Saving tokens to localStorage');
      localStorage.setItem('accessToken', this.accessToken);
      localStorage.setItem('refreshToken', this.refreshToken);
      localStorage.setItem('user', JSON.stringify(this.user));

      console.log('Redirecting to dashboard');
      window.location.href = '/dashboard';
    } catch (error) {
      console.error('Login error:', error);
      errorElement.textContent = error.message;
      errorElement.style.display = 'block';
    }
  }

  async handleSignup(e) {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const errorElement = document.getElementById('signup-error');

    // Check if passwords match
    if (password !== confirmPassword) {
      errorElement.textContent = 'Passwords do not match';
      errorElement.style.display = 'block';
      return;
    }

    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, email, password })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Signup failed');
      }

      // Save tokens and user info
      this.accessToken = data.accessToken;
      this.refreshToken = data.refreshToken;
      this.user = data.user;

      localStorage.setItem('accessToken', this.accessToken);
      localStorage.setItem('refreshToken', this.refreshToken);
      localStorage.setItem('user', JSON.stringify(this.user));

      // Use the redirect URL from the response if available
      if (data.redirectUrl) {
        window.location.href = data.redirectUrl;
      } else if (!this.user.hasPaid) {
        window.location.href = '/payment';
      } else {
        window.location.href = '/dashboard';
      }
    } catch (error) {
      errorElement.textContent = error.message;
      errorElement.style.display = 'block';
    }
  }

  async handleLogout(e) {
    e.preventDefault();

    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.accessToken}`
        },
        body: JSON.stringify({ refreshToken: this.refreshToken })
      });
    } catch (error) {
      console.error('Logout error:', error);
    }

    // Clear local storage
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');

    // Redirect to login page
    window.location.href = '/login';
  }

  setupTokenRefresh() {
    // Set up token refresh before it expires
    const tokenPayload = JSON.parse(atob(this.accessToken.split('.')[1]));
    const expiryTime = tokenPayload.exp * 1000; // Convert to milliseconds
    const currentTime = Date.now();
    const timeUntilExpiry = expiryTime - currentTime;

    // Refresh token 5 minutes before it expires
    const refreshTime = Math.max(timeUntilExpiry - 5 * 60 * 1000, 0);

    setTimeout(() => {
      this.refreshAccessToken();
    }, refreshTime);
  }

  async refreshAccessToken() {
    try {
      const response = await fetch('/api/auth/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ refreshToken: this.refreshToken })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Token refresh failed');
      }

      // Update access token
      this.accessToken = data.accessToken;
      localStorage.setItem('accessToken', this.accessToken);

      // Set up next refresh
      this.setupTokenRefresh();
    } catch (error) {
      console.error('Token refresh error:', error);

      // If refresh fails, logout user
      this.handleLogout(new Event('click'));
    }
  }

  isAuthenticated() {
    console.log('=== DEBUG: isAuthenticated() called ===');
    console.log('Access token exists:', !!this.accessToken);

    if (!this.accessToken) {
      console.log('No access token found');
      return false;
    }

    try {
      // Check if token is expired
      const tokenParts = this.accessToken.split('.');
      if (tokenParts.length !== 3) {
        console.log('Invalid token format');
        return false;
      }

      const tokenPayload = JSON.parse(atob(tokenParts[1]));
      const currentTime = Math.floor(Date.now() / 1000);

      console.log('Token payload:', tokenPayload);
      console.log('Current time:', currentTime);
      console.log('Token expires at:', tokenPayload.exp);
      console.log('Time until expiration:', tokenPayload.exp - currentTime);

      // If token is expired or will expire in the next 30 seconds, return false
      if (tokenPayload.exp < currentTime + 30) {
        console.log('Token expired or expiring soon');
        return false;
      }

      console.log('Token is valid');
      return true;
    } catch (error) {
      console.error('Error validating token:', error);
      return false;
    }
  }

  hasPaid() {
    console.log('=== DEBUG: hasPaid() called ===');
    console.log('User object:', this.user);

    if (!this.user) {
      console.log('No user object found');
      return false;
    }

    const hasPaid = this.user.hasPaid || false;
    console.log('User hasPaid status:', hasPaid);
    return hasPaid;
  }

  isFirstLogin() {
    return this.user.isFirstLogin;
  }
}

// Initialize auth
const auth = new Auth();