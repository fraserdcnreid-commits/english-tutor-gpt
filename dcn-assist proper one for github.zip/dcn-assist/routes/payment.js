const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { getUserById, updateUser } = require('../db/queries');

// Authentication middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// Create payment intent
router.post('/create-payment-intent', authenticateToken, async (req, res) => {
  try {
    const user = await getUserById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: 1000, // $10.00
      currency: 'usd',
      metadata: {
        userId: req.user.id
      }
    });

    res.json({
      clientSecret: paymentIntent.client_secret
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Confirm payment
router.post('/confirm-payment', authenticateToken, async (req, res) => {
  try {
    const { paymentIntentId } = req.body;

    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

    if (paymentIntent.status !== 'succeeded') {
      return res.status(400).json({ message: 'Payment not successful' });
    }

    // Verify payment belongs to authenticated user
    if (paymentIntent.metadata.userId !== req.user.id) {
      return res.status(403).json({ message: 'Payment verification failed' });
    }

    const user = await getUserById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    await updateUser(user.email, { ...user, hasPaid: true });

    res.json({ message: 'Payment confirmed' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Toggle payment requirement
router.post('/toggle-payment', authenticateToken, async (req, res) => {
  try {
    const { requirePayment } = req.body;

    process.env.REQUIRE_PAYMENT = requirePayment;

    res.json({ 
      message: `Payment requirement ${requirePayment ? 'enabled' : 'disabled'}`,
      requirePayment
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// getUserById is now imported from db/queries.js

module.exports = router;