// UI functionality
class UI {
  constructor() {
    this.currentTheme = localStorage.getItem('theme') || 'default';
    this.init();
  }

  init() {
    // Set initial theme
    this.setTheme(this.currentTheme);

    // Theme toggle
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
      themeToggle.addEventListener('click', this.toggleTheme.bind(this));
    }

    // Sidebar toggle
    const sidebarToggle = document.getElementById('sidebar-toggle');
    if (sidebarToggle) {
      sidebarToggle.addEventListener('click', this.toggleSidebar.bind(this));
    }

    // User menu toggle
    const userMenuToggle = document.getElementById('user-menu-toggle');
    if (userMenuToggle) {
      userMenuToggle.addEventListener('click', this.toggleUserMenu.bind(this));
    }

    // Tutorial modal
    const tutorialBtn = document.getElementById('tutorial-btn');
    const tutorialModal = document.getElementById('tutorial-modal');
    const closeTutorial = document.getElementById('close-tutorial');

    if (tutorialBtn && tutorialModal) {
      tutorialBtn.addEventListener('click', () => {
        tutorialModal.classList.add('show');
      });
    }

    if (closeTutorial && tutorialModal) {
      closeTutorial.addEventListener('click', () => {
        tutorialModal.classList.remove('show');
      });
    }

    // Close modals when clicking outside
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal')) {
        e.target.classList.remove('show');
      }
    });

    // Close user menu when clicking outside
    document.addEventListener('click', (e) => {
      const userMenu = document.getElementById('user-menu');
      const userMenuDropdown = document.getElementById('user-menu-dropdown');

      if (userMenu && userMenuDropdown && !userMenu.contains(e.target)) {
        userMenuDropdown.classList.remove('show');
      }
    });

    // Walkthrough button
    const walkthroughBtn = document.getElementById('walkthrough-btn');
    if (walkthroughBtn) {
      walkthroughBtn.addEventListener('click', () => {
        walkthrough.start();
      });
    }

    // Add smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
          target.scrollIntoView({
            behavior: 'smooth'
          });
        }
      });
    });

    // Add ripple effect to buttons
    this.addRippleEffect();
  }

  setTheme(theme) {
    const themeStylesheet = document.getElementById('theme-stylesheet');
    if (themeStylesheet) {
      themeStylesheet.href = `css/themes/${theme}.css`;
    }
    this.currentTheme = theme;
    localStorage.setItem('theme', theme);

    // Add a subtle animation when changing themes
    document.body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
  }

  toggleTheme() {
    const themes = ['default', 'dark', 'light'];
    const currentIndex = themes.indexOf(this.currentTheme);
    const nextIndex = (currentIndex + 1) % themes.length;
    const nextTheme = themes[nextIndex];
    this.setTheme(nextTheme);
  }

  toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
      sidebar.classList.toggle('show');
    }
  }

  toggleUserMenu() {
    const userMenuDropdown = document.getElementById('user-menu-dropdown');
    if (userMenuDropdown) {
      userMenuDropdown.classList.toggle('show');
    }
  }

  addRippleEffect() {
    const buttons = document.querySelectorAll('.btn');

    buttons.forEach(button => {
      button.addEventListener('click', function(e) {
        const ripple = document.createElement('span');
        const rect = this.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;

        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        ripple.classList.add('ripple');

        this.appendChild(ripple);

        setTimeout(() => {
          ripple.remove();
        }, 600);
      });
    });
  }
}

// Initialize UI
const ui = new UI();