const pool = require('./connection');

// User operations
const createUser = async (user) => {
  const query = `
    INSERT INTO users (id, username, email, password, created_at, has_paid, has_logged_in)
    VALUES ($1, $2, $3, $4, $5, $6, $7)
    RETURNING *
  `;
  const values = [
    user.id,
    user.username, 
    user.email,
    user.password,
    new Date(user.createdAt),
    user.hasPaid || false,
    user.hasLoggedIn || false
  ];
  const result = await pool.query(query, values);
  return result.rows[0];
};

const getUserByEmail = async (email) => {
  const query = 'SELECT * FROM users WHERE email = $1';
  const result = await pool.query(query, [email]);
  const user = result.rows[0];
  if (!user) return null;
  
  return {
    ...user,
    hasPaid: user.has_paid,
    hasLoggedIn: user.has_logged_in,
    createdAt: user.created_at.toISOString()
  };
};

const getUserById = async (userId) => {
  const query = 'SELECT * FROM users WHERE id = $1';
  const result = await pool.query(query, [userId]);
  const user = result.rows[0];
  if (!user) return null;
  
  return {
    ...user,
    hasPaid: user.has_paid,
    hasLoggedIn: user.has_logged_in,
    createdAt: user.created_at.toISOString()
  };
};

const updateUser = async (email, updates) => {
  const setClause = [];
  const values = [email];
  let valueIndex = 2;
  
  if (updates.username !== undefined) {
    setClause.push(`username = $${valueIndex}`);
    values.push(updates.username);
    valueIndex++;
  }
  if (updates.hasPaid !== undefined) {
    setClause.push(`has_paid = $${valueIndex}`);
    values.push(updates.hasPaid);
    valueIndex++;
  }
  if (updates.hasLoggedIn !== undefined) {
    setClause.push(`has_logged_in = $${valueIndex}`);
    values.push(updates.hasLoggedIn);
    valueIndex++;
  }
  
  if (setClause.length === 0) {
    const user = await getUserByEmail(email);
    return user;
  }
  
  const query = `UPDATE users SET ${setClause.join(', ')} WHERE email = $1 RETURNING *`;
  const result = await pool.query(query, values);
  const user = result.rows[0];
  
  return {
    ...user,
    hasPaid: user.has_paid,
    hasLoggedIn: user.has_logged_in,
    createdAt: user.created_at.toISOString()
  };
};

// Refresh token operations
const setRefreshToken = async (userId, token) => {
  const query = `
    INSERT INTO refresh_tokens (user_id, token)
    VALUES ($1, $2)
    ON CONFLICT (user_id)
    DO UPDATE SET token = $2, created_at = CURRENT_TIMESTAMP
  `;
  await pool.query(query, [userId, token]);
};

const getRefreshToken = async (userId) => {
  const query = 'SELECT token FROM refresh_tokens WHERE user_id = $1';
  const result = await pool.query(query, [userId]);
  return result.rows[0]?.token || null;
};

const deleteRefreshToken = async (userId) => {
  const query = 'DELETE FROM refresh_tokens WHERE user_id = $1';
  await pool.query(query, [userId]);
};

// Chat operations
const createChat = async (chat) => {
  const query = `
    INSERT INTO chats (id, user_id, title, messages, created_at, updated_at)
    VALUES ($1, $2, $3, $4, $5, $6)
    RETURNING *
  `;
  const values = [
    chat.id,
    chat.userId,
    chat.title,
    JSON.stringify(chat.messages || []),
    new Date(chat.createdAt),
    new Date(chat.updatedAt)
  ];
  const result = await pool.query(query, values);
  const row = result.rows[0];
  return {
    ...row,
    user_id: row.user_id,
    userId: row.user_id,
    messages: typeof row.messages === 'string' ? JSON.parse(row.messages) : row.messages,
    createdAt: row.created_at.toISOString(),
    updatedAt: row.updated_at.toISOString()
  };
};

const getChatsByUserId = async (userId) => {
  const query = 'SELECT * FROM chats WHERE user_id = $1 ORDER BY created_at DESC';
  const result = await pool.query(query, [userId]);
  return result.rows.map(row => ({
    ...row,
    userId: row.user_id,
    messages: typeof row.messages === 'string' ? JSON.parse(row.messages) : row.messages,
    createdAt: row.created_at.toISOString(),
    updatedAt: row.updated_at.toISOString()
  }));
};

const getChatById = async (userId, chatId) => {
  const query = 'SELECT * FROM chats WHERE user_id = $1 AND id = $2';
  const result = await pool.query(query, [userId, chatId]);
  if (!result.rows[0]) return null;
  
  const row = result.rows[0];
  return {
    ...row,
    userId: row.user_id,
    messages: typeof row.messages === 'string' ? JSON.parse(row.messages) : row.messages,
    createdAt: row.created_at.toISOString(),
    updatedAt: row.updated_at.toISOString()
  };
};

const updateChat = async (userId, chatId, updates) => {
  const query = `
    UPDATE chats 
    SET title = COALESCE($3, title), 
        messages = COALESCE($4, messages),
        updated_at = CURRENT_TIMESTAMP
    WHERE user_id = $1 AND id = $2
    RETURNING *
  `;
  const values = [
    userId, 
    chatId, 
    updates.title, 
    updates.messages ? JSON.stringify(updates.messages) : null
  ];
  const result = await pool.query(query, values);
  if (!result.rows[0]) return null;
  
  const row = result.rows[0];
  return {
    ...row,
    userId: row.user_id,
    messages: typeof row.messages === 'string' ? JSON.parse(row.messages) : row.messages,
    createdAt: row.created_at.toISOString(),
    updatedAt: row.updated_at.toISOString()
  };
};

const deleteChat = async (userId, chatId) => {
  const query = 'DELETE FROM chats WHERE user_id = $1 AND id = $2';
  const result = await pool.query(query, [userId, chatId]);
  return result.rowCount > 0;
};

const searchChatsByTitle = async (userId, searchQuery) => {
  const query = `
    SELECT * FROM chats 
    WHERE user_id = $1 AND LOWER(title) LIKE LOWER($2)
    ORDER BY created_at DESC
  `;
  const result = await pool.query(query, [userId, `%${searchQuery}%`]);
  return result.rows.map(row => ({
    ...row,
    userId: row.user_id,
    messages: typeof row.messages === 'string' ? JSON.parse(row.messages) : row.messages,
    createdAt: row.created_at.toISOString(),
    updatedAt: row.updated_at.toISOString()
  }));
};

module.exports = {
  createUser,
  getUserByEmail,
  getUserById,
  updateUser,
  setRefreshToken,
  getRefreshToken,
  deleteRefreshToken,
  createChat,
  getChatsByUserId,
  getChatById,
  updateChat,
  deleteChat,
  searchChatsByTitle
};