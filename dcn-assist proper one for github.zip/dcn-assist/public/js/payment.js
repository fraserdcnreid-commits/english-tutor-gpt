// Payment functionality
class Payment {
  constructor() {
    this.stripe = Stripe('pk_test_YOUR_PUBLISHABLE_KEY'); // Replace with your Stripe publishable key
    this.elements = this.stripe.elements();
    this.init();
  }

  init() {
    // Check if user is authenticated
    if (!auth.isAuthenticated()) {
      window.location.href = '/login';
      return;
    }

    // Check if user has already paid
    if (auth.hasPaid()) {
      window.location.href = '/dashboard';
      return;
    }

    // Set up Stripe Elements
    this.card = this.elements.create('card', {
      style: {
        base: {
          color: '#32325d',
          fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
          fontSmoothing: 'antialiased',
          fontSize: '16px',
          '::placeholder': {
            color: '#aab7c4'
          }
        },
        invalid: {
          color: '#fa755a',
          iconColor: '#fa755a'
        }
      }
    });

    // Mount card element
    this.card.mount('#card-element');

    // Handle real-time validation errors from the card Element
    this.card.on('change', (event) => {
      const displayError = document.getElementById('card-errors');
      if (event.error) {
        displayError.textContent = event.error.message;
        displayError.style.display = 'block';
      } else {
        displayError.textContent = '';
        displayError.style.display = 'none';
      }
    });

    // Handle form submission
    const form = document.getElementById('payment-form');
    form.addEventListener('submit', this.handleSubmit.bind(this));
  }

  async handleSubmit(event) {
    event.preventDefault();

    const submitButton = document.getElementById('submit-payment');
    const errorMessage = document.getElementById('payment-error');
    const successMessage = document.getElementById('payment-message');

    // Disable submit button
    submitButton.disabled = true;
    submitButton.textContent = 'Processing...';

    // Hide previous messages
    errorMessage.style.display = 'none';
    successMessage.style.display = 'none';

    try {
      // Create payment intent on the server
      const response = await fetch('/api/payment/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${auth.accessToken}`
        },
        body: JSON.stringify({
          userId: auth.user.id
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to create payment intent');
      }

      // Confirm card payment
      const result = await this.stripe.confirmCardPayment(data.clientSecret, {
        payment_method: {
          card: this.card,
          billing_details: {
            name: auth.user.username,
            email: auth.user.email
          }
        }
      });

      if (result.error) {
        // Show error to your customer
        errorMessage.textContent = result.error.message;
        errorMessage.style.display = 'block';

        // Re-enable submit button
        submitButton.disabled = false;
        submitButton.textContent = 'Pay $10.00';
      } else {
        // The payment has been processed!
        if (result.paymentIntent.status === 'succeeded') {
          // Confirm payment with server
          await this.confirmPayment(result.paymentIntent.id);

          // Show success message
          successMessage.textContent = 'Payment successful! Redirecting to dashboard...';
          successMessage.style.display = 'block';

          // Update user info
          auth.user.hasPaid = true;
          localStorage.setItem('user', JSON.stringify(auth.user));

          // Redirect to dashboard after a short delay
          setTimeout(() => {
            window.location.href = '/dashboard';
          }, 2000);
        }
      }
    } catch (error) {
      console.error('Payment error:', error);

      errorMessage.textContent = error.message;
      errorMessage.style.display = 'block';

      // Re-enable submit button
      submitButton.disabled = false;
      submitButton.textContent = 'Pay $10.00';
    }
  }

  async confirmPayment(paymentIntentId) {
    try {
      const response = await fetch('/api/payment/confirm-payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${auth.accessToken}`
        },
        body: JSON.stringify({
          paymentIntentId,
          userId: auth.user.id
        })
      });

      if (!response.ok) {
        throw new Error('Failed to confirm payment');
      }

      return await response.json();
    } catch (error) {
      console.error('Error confirming payment:', error);
      throw error;
    }
  }
}

// Initialize payment
const payment = new Payment();