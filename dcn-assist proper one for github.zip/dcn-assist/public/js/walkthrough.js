// Walkthrough functionality
class Walkthrough {
  constructor() {
    this.steps = [
      {
        element: '#sidebar',
        title: 'Chat History',
        description: 'Here you can see all your previous conversations. Click on any chat to continue it.',
        position: 'right'
      },
      {
        element: '#new-chat-btn',
        title: 'New Chat',
        description: 'Click this button to start a new conversation with your English tutor.',
        position: 'top'
      },
      {
        element: '#chat-input',
        title: 'Message Input',
        description: 'Type your English questions here and press Enter to send. The AI will respond instantly!',
        position: 'top'
      },
      {
        element: '#theme-toggle',
        title: 'Theme Selector',
        description: 'Click here to change the application theme between light, dark, and default.',
        position: 'left'
      },
      {
        element: '#tutorial-btn',
        title: 'Tutorial',
        description: 'Click here to see tips on how to get the best out of your AI English tutor.',
        position: 'left'
      }
    ];
    this.currentStep = 0;
    this.init();
  }

  init() {
    this.overlay = document.getElementById('walkthrough-overlay');
    this.tooltip = document.getElementById('walkthrough-tooltip');
    this.title = document.getElementById('walkthrough-title');
    this.description = document.getElementById('walkthrough-description');
    this.stepIndicator = document.getElementById('walkthrough-step');
    this.prevBtn = document.getElementById('walkthrough-prev');
    this.nextBtn = document.getElementById('walkthrough-next');
    this.skipBtn = document.getElementById('walkthrough-skip');

    if (this.prevBtn) {
      this.prevBtn.addEventListener('click', this.prevStep.bind(this));
    }

    if (this.nextBtn) {
      this.nextBtn.addEventListener('click', this.nextStep.bind(this));
    }

    if (this.skipBtn) {
      this.skipBtn.addEventListener('click', this.end.bind(this));
    }

    // Close walkthrough when clicking outside
    if (this.overlay) {
      this.overlay.addEventListener('click', (e) => {
        if (e.target === this.overlay) {
          this.end();
        }
      });
    }
  }

  start() {
    this.currentStep = 0;
    this.showStep();
    this.overlay.classList.add('show');
  }

  showStep() {
    const step = this.steps[this.currentStep];
    const element = document.querySelector(step.element);

    if (!element) {
      console.error(`Element not found: ${step.element}`);
      this.nextStep();
      return;
    }

    // Update content
    this.title.textContent = step.title;
    this.description.textContent = step.description;
    this.stepIndicator.textContent = `${this.currentStep + 1} / ${this.steps.length}`;

    // Update buttons
    this.prevBtn.style.display = this.currentStep === 0 ? 'none' : 'block';
    this.nextBtn.textContent = this.currentStep === this.steps.length - 1 ? 'Finish' : 'Next';

    // Position tooltip
    this.positionTooltip(element, step.position);

    // Highlight element
    this.highlightElement(element);
  }

  positionTooltip(element, position) {
    const elementRect = element.getBoundingClientRect();
    const tooltipRect = this.tooltip.getBoundingClientRect();

    // Reset tooltip position
    this.tooltip.style.top = '';
    this.tooltip.style.left = '';
    this.tooltip.style.right = '';
    this.tooltip.style.bottom = '';

    // Position based on specified position
    switch (position) {
      case 'top':
        this.tooltip.style.bottom = `${window.innerHeight - elementRect.top + 15}px`;
        this.tooltip.style.left = `${elementRect.left + elementRect.width / 2 - tooltipRect.width / 2}px`;
        break;
      case 'right':
        this.tooltip.style.left = `${elementRect.right + 15}px`;
        this.tooltip.style.top = `${elementRect.top + elementRect.height / 2 - tooltipRect.height / 2}px`;
        break;
      case 'bottom':
        this.tooltip.style.top = `${elementRect.bottom + 15}px`;
        this.tooltip.style.left = `${elementRect.left + elementRect.width / 2 - tooltipRect.width / 2}px`;
        break;
      case 'left':
        this.tooltip.style.right = `${window.innerWidth - elementRect.left + 15}px`;
        this.tooltip.style.top = `${elementRect.top + elementRect.height / 2 - tooltipRect.height / 2}px`;
        break;
    }

    // Adjust if tooltip goes out of viewport
    this.adjustTooltipPosition();
  }

  adjustTooltipPosition() {
    const tooltipRect = this.tooltip.getBoundingClientRect();
    const margin = 15;

    // Adjust horizontal position if out of viewport
    if (tooltipRect.left < margin) {
      this.tooltip.style.left = `${margin}px`;
      this.tooltip.style.right = 'auto';
    } else if (tooltipRect.right > window.innerWidth - margin) {
      this.tooltip.style.right = `${margin}px`;
      this.tooltip.style.left = 'auto';
    }

    // Adjust vertical position if out of viewport
    if (tooltipRect.top < margin) {
      this.tooltip.style.top = `${margin}px`;
      this.tooltip.style.bottom = 'auto';
    } else if (tooltipRect.bottom > window.innerHeight - margin) {
      this.tooltip.style.bottom = `${margin}px`;
      this.tooltip.style.top = 'auto';
    }
  }

  highlightElement(element) {
    // Remove previous highlights
    document.querySelectorAll('.walkthrough-highlight').forEach(el => {
      el.classList.remove('walkthrough-highlight');
    });

    // Add highlight to current element
    element.classList.add('walkthrough-highlight');
  }

  nextStep() {
    if (this.currentStep < this.steps.length - 1) {
      this.currentStep++;
      this.showStep();
    } else {
      this.end();
    }
  }

  prevStep() {
    if (this.currentStep > 0) {
      this.currentStep--;
      this.showStep();
    }
  }

  end() {
    this.overlay.classList.remove('show');

    // Remove highlights
    document.querySelectorAll('.walkthrough-highlight').forEach(el => {
      el.classList.remove('walkthrough-highlight');
    });
  }
}

// Initialize walkthrough
const walkthrough = new Walkthrough();